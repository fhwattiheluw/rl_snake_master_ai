"""tournament.py — Simulasi kompetisi round—robin antar model Snake AI"""
import os
import glob
import numpy as np
import pandas as pd
from stable_baselines3 import PPO
from stable_baselines3.common.monitor import Monitor
from snake_env import SnakeEnv
def evaluate_single_model(model_path, n _ episodes=30):
env = SnakeEnv(render_mode=None) # Tanpa GUI agar proses cepat
env = Monitor(env)
model = PPO.load (model_path, env=env)
scores
for _ in range (n_episodes):
obs, info = env.reset()
done = False
total_reward = 0
while not done:
action, _ = model . predict (obs, deterministic—True)
obs, reward, terminated, truncated, info = env.step(action)
done = terminated or truncated
total_reward += reward
scores.append (info.get ("score",total reward))
env.close ()
return np.mean (scores), np.std (scores)
def run_tournament(folder="models/", n_episodes=30):
model_files =
glob.glob(os.path.join(folder,"*.zip"))
if not model_files:
print (f"X Tidak ada file model (.zip) yang ditemukan di folder '{folder}'")
return None
print (f"MEMULA1 TURNAMEN SNAKE A1\nCJ Ditemukan {len(modelfiles)}peserta")
print("-" * 50)
results = []
for i, mf in enumerate (model files, 1):
name = os.path.basename (mf)
print (f"[{i}/{(model files)}] Mengevaluasi performa {name} ...")
avg, std = evaluate_single_model (mf, n_episodes)
results.append({
"Peringkat": 0, "Nama Model": name, "Rata—rata Skor": round(avg,2),"Std Dev":round (std,2) })
# Pemrosesan dan pengurutan data menggunakan Pandas
df = pd.DataFrame (results)
df = df.sort_values ("Rata-rata Skor"
ascending=FaIse).reset_index (drop=True)
=df["Peringkat"] = df.index + 1
print ("\n" + "="*60 + "\nKLASEMEN AKHIR TURNAMEN\n" + "="*60)
print (df.to_string (index=EaIse) )
print ("="*60)
df.to_csv("tournament_results.csv", index=False)
print(f"\nJUARA PERTAMA: {df.iloc[0]['Nama Model']} (Skor:{df,iloc[0]['Rata-Rata Skor']})")
if__name__ == "__main__":
    run_tournament("models/", 30)