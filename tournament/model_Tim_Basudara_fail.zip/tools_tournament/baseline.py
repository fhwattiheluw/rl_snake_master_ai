"""baseline.py - Agent Random dan Rule-Based untuk pembanding di turnamen."""
import random
import numpy as np
class RandomAgent:
"""Agent acak — untuk baseline terendah"""
def predict (self, obs, deterministic—True):
return random.randint (0, 3), None
class RuleBasedAgent:
"""
Agent berbasis aturan sederhana untuk Snake.
Strategi: prioritaskan bergerak lurus ke arah makanan terdekat.
"""
def_init_(self)
# Pemetaan aksi: 0=atas, 1=kanan, 2=bawah, 3=kiri
self. direction map = {0: (0, -1), 1: (1, 0) 2: (0, 1), 3: (-1, 0)}
def predict (self, obs, deterministic—True):
"""
obs array II dimensi: (danger_straight, danger_right, danger_left, dir_up, dir_right, dir_down, dir_left, food_up, food_right, food_down, food_left)
"""
# Ekstrak informasi posisi makanan dari array observasi
food_up = obs(7)
food_right = obs(8)
food_down = obs(9)
food_left = obs(10)
# Penentuan aksi berdasarkan posisi makanan
if food_up == 1:
return 0, None  # atas
elif food_right == 1:
return 1, None  # kanan
elif food down == 1:
return 2, None  # bawah
elif food left == 1:
return 3, None  #kiri
else:return random. randint (0, 3), None
if__name__ == "__main__"
agent = RuleBasedAgent()
print ("Rule-Based Agent berhasil diinisialisasi dan siap digunakan.")