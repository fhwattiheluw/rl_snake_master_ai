"""evaluate.py — Script Evaluasi Model untuk Turnamen Snake AI"""
import os
import gymnasium as gym
import numpy as np
from stable baselines3 import PPO
from stable baselines3. common . monitor import Monitor
from snake env import SnakeEnv
def evaluate_model (model_path, n_episodes=1OO, render=False):
# Inisialisasi environment
env = SnakeEnv (render if render else None)
env = Monitor (env)
# Load model
model =PPO. load (model_path, env=env)
scores, wins, max score = [],0 ,0
# Eksekusi evaluasi
for ep in range (n_episodes):
obs,info = env.reset()
done = False
total reward = 0
while not done:
action, _ = model.predict (obs, deterministic—True)
obs, reward, terminated, truncated, info = env. step (action)
done = terminated or truncated
total_reward += reward
score = info. get("score", total_reward)
scores.append(score)
max_score = max(max score, score)
if score > 0: wins += 1
print (f"Episode {ep+1}/{n_episodes}: skor = {score}")
env.close ()
# Perhitungan statistik
avg_score = np.mean (scores)
std_score = np.std (scores)
win_rate = (wins / n_episodes)100 

# Cetak hasil
print ("\n" + "="*50)
print (f"EVALUASI MODEL: {os.path.basename(model_path}")
print ("="*50)
print (f"Rata—rata Skor : {avg score:.2f} ± {std score:.2f}")
print (f"Skor Maksimum : {max score}")
print (f"Tingkat Kemenangan : {win_rate:.2f}%"}
print ("="*50)
return {"avg": avg_score,"std": std_score, "max":max score, "win":win_rate}
if__name__=="__main__":
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("——model", type=str,default="models/snake_model.zip", help="Path model .zip")
parser.add argument ("——episodes", type=int, default=100, help="Total episode evaluasi") 
parser.add argument ("——render", action="store_true", help="Aktifkan tampilan GUI")
args = parser.parse_args()
evaluate_model (args.model, args.episodes, args.render)