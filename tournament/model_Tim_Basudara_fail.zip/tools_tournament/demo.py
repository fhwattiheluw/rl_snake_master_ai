"""demo.py - Script eksekusi model dengan Graphical User Interface (GUI)untuk perekaman video."""
from stable_baselines3 import PPO
from snake-env import SnakeEnv
def run_demo(model_path="models/snake_model.zip", n_games=3):
# Render mode 'human' untuk menampilkan pop—up GUI Pygame
env = SnakeEnv (render_mode="human")
model = PPO.load(model_path)
for game in range (n _ games):
obs, info = env.reset ()
done = False
total score = 0
print (f"\n Pertandingan ke-{game+1} dimulai.....")
while not done : action, _ = model.predict (obs, deterministic=True)
obs, reward, terminated, truncated, info = env. step (action)
done = terminated or truncated
total score += reward
score = info.get("score",total_score)
print (f"CD Pertandingan ke-{game+1} selesai! Skor akhir: {score}")
env.close()
if__name__ == "__main__":
import argparse
parser = argparse.Argument Parser()
parser.add argument ("——model", type=str, default="models/snake_model.zip")
parser.add argument ("——games", type=int, default=3)
args=parser.parse_args()
run_demo(args.model, args.games)